#include <stdio.h>

int main(void)
{
	int age = 20;
	printf("%d\n", age);
	age = 21;
	printf("%d\n", age);

	return 0;
}