#include <stdio.h>

int main(void)
{
	char kor[] = "�����ڵ�";
	printf("%s\n", kor);
	printf("%d\n", sizeof(kor));

	return 0;
}          
