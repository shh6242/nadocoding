#include <stdio.h>

int main(void)
{
	int arr[10] = { 1, 2 }; // �Ϻ� �� �ʱ�ȭ

	for (int i = 0; i < 10; i++)
	{
		printf("%d\n", arr[i]); 
	}
	return 0;
}          
