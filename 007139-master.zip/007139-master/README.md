# <코딩 자율학습 나도코딩의 C 언어 입문> 

이 저장소에는 <코딩 자율학습 나도코딩의 C 언어 입문>의 예제 소스 코드가 담겨 있습니다.

![cove_코자 C_입체](https://user-images.githubusercontent.com/6995518/192201814-29976aa2-b923-4155-abe6-8367cdc1519b.png)

## 예제 코드 다운로드 및 확인 방법

- 화면 위쪽에 보이는 [Code] 버튼을 클릭합니다.
- 아래로 펼쳐지는 메뉴에서 [Download ZIP]을 클릭해 압축 파일을 내려받습니다. 
- 내려받은 파일의 압축을 풀면 장별로 폴더가 있습니다.  
- 장별로 개별 코드와 통합 코드 2가지가 있습니다.
- 셀프체크 문제 정답은 selfcheck 폴더에 담겨 있습니다.

## macOS에서 개발 환경 설정하기

- 이 책은 Windows를 기준으로 설명합니다. 운영체제가 macOS라면 별도의 개발 환경 설정이 필요하므로 다음 링크를 참고해 주세요. 
- Xcode로 실습 시: https://nadocoding.tistory.com/94
- VSCode로 실습 시: https://nadocoding.tistory.com/95
- macOS용 소스 코드: https://nadocoding.tistory.com/96





